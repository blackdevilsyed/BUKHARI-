
import { useState, useEffect } from "react";

function App() {
  const [courses,setCourses]=useState([]);
  const [title,setTitle]=useState("");
  const [image,setImage]=useState("");
  const [video,setVideo]=useState("");
  const [amount,setAmount]=useState("");

  useEffect(()=>{
    fetch("http://localhost:5000/courses")
    .then(r=>r.json())
    .then(d=>setCourses(d));
  },[]);

  const addCourse=async()=>{
    await fetch("http://localhost:5000/add-course",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({title,image,video,amount})
    });
    alert("Added");
  };

  const pay=async(i)=>{
    await fetch("http://localhost:5000/payment",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({course:i})
    });
    alert("Payment Submitted");
  };

  return(
    <div style={{padding:20,fontFamily:"sans-serif"}}>
      <h1>WAHAB BUKHARI Academy</h1>

      <h2>Add Course</h2>
      <input placeholder="Title" onChange={e=>setTitle(e.target.value)} />
      <input placeholder="Image URL" onChange={e=>setImage(e.target.value)} />
      <input placeholder="Drive Link (embed)" onChange={e=>setVideo(e.target.value)} />
      <input placeholder="Price" onChange={e=>setAmount(e.target.value)} />
      <button onClick={addCourse}>Add Course</button>

      <h2>Courses</h2>
      {courses.map((c,i)=>(
        <div key={i} style={{border:"1px solid #ccc",margin:10,padding:10}}>
          <h3>{c.title}</h3>
          <img src={c.image} width="200"/>
          <p>Price: {c.amount}</p>
          <iframe src={c.video} width="300" height="200"></iframe>
          <br/>
          <button onClick={()=>pay(i)}>Buy / Submit Payment</button>
        </div>
      ))}
    </div>
  );
}

export default App;
