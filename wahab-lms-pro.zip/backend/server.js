
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let courses = [];
let payments = [];

const ADMIN = {
  email: "syedabdulwahabbukhari8@gmail.com",
  password: "Devil X"
};

// Admin Login
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (email === ADMIN.email && password === ADMIN.password) {
    return res.json({ success: true });
  }
  res.json({ success: false });
});

// Add Course
app.post("/add-course", (req, res) => {
  courses.push(req.body);
  res.json({ success: true });
});

// Get Courses
app.get("/courses", (req, res) => {
  res.json(courses);
});

// Payment Submit
app.post("/payment", (req, res) => {
  payments.push({ ...req.body, approved: false });
  res.json({ success: true });
});

// Admin Approve Payment
app.post("/approve", (req, res) => {
  const { index } = req.body;
  payments[index].approved = true;
  res.json({ success: true });
});

// Get Payments
app.get("/payments", (req, res) => {
  res.json(payments);
});

app.listen(5000, () => console.log("Server running"));
